package com.thilina.UIdemoDTO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UIdemoDtoApplication {

	public static void main(String[] args) {
		SpringApplication.run(UIdemoDtoApplication.class, args);
	}

}
